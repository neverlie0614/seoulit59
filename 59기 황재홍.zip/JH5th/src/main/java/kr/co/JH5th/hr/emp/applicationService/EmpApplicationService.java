package kr.co.JH5th.hr.emp.applicationService;

import java.util.List;

import kr.co.JH5th.hr.emp.to.EmployeeTO;

public interface EmpApplicationService {

	public List<EmployeeTO> findEmployeeList();
	
}
