package kr.co.JH5th.base.exception;

@SuppressWarnings("serial")
public class CodeListException extends Exception{
	public CodeListException(String msg){ super(msg); }
}
