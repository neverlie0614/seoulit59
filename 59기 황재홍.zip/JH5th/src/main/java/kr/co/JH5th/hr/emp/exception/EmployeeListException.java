package kr.co.JH5th.hr.emp.exception;

@SuppressWarnings("serial")
public class EmployeeListException extends Exception{
	public EmployeeListException(String msg){ super(msg); }
}
