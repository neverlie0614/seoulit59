package kr.co.JH5th.base.exception;

@SuppressWarnings("serial")
public class DetailCodeListException extends Exception{
	public DetailCodeListException(String msg){ super(msg); }
}
