package kr.co.JH5th.base.exception;

public class PwMissmatchException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PwMissmatchException(String msg){ super(msg); }
}
