package kr.co.JH5th.base.dao;

import java.util.List;

import kr.co.JH5th.base.to.CodeTO;

public interface CodeDAO{

	public List<CodeTO> selectCodeList();
	// 코드 리스트 조회
	
	
}
