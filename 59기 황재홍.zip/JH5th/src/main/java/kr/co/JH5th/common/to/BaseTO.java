package kr.co.JH5th.common.to;

public class BaseTO {

	protected String status = "noraml";

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	
}
