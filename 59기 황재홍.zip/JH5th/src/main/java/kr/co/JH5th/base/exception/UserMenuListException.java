package kr.co.JH5th.base.exception;

@SuppressWarnings("serial")
public class UserMenuListException extends Exception{
	public UserMenuListException(String msg){ super(msg); }
}
