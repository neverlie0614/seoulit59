package kr.co.JH5th.logistics.base.exception;

public class DeptCodeNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public DeptCodeNotFoundException(String msg){ super(msg); }

}
